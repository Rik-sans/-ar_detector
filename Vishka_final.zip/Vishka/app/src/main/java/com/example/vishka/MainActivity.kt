package com.example.vishka



import android.app.Activity

import android.content.Context

import android.content.pm.ActivityInfo

import android.graphics.*

import android.os.Bundle

import android.view.*

import org.json.JSONObject

import java.net.DatagramPacket

import java.net.DatagramSocket

import java.nio.charset.StandardCharsets

import kotlin.concurrent.Volatile

import kotlin.math.atan2



class MainActivity : Activity() {



    @Volatile private var listening = false

    private var udpThread: Thread? = null

    private lateinit var drawingView: DrawingView



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)



        // Горизонтальный режим

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        requestWindowFeature(Window.FEATURE_NO_TITLE)

        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)



        drawingView = DrawingView(this)

        drawingView.setBackgroundColor(Color.parseColor("#1E1E1E"))

        setContentView(drawingView)



        startUdpListener()

    }

    private fun stopUdpListener() {

        listening = false

        udpThread?.interrupt()

        udpThread = null

    }

    override fun onDestroy() {

        super.onDestroy()

        stopUdpListener()

    }



    private fun startUdpListener() {

        if (listening) return

        listening = true

        udpThread = Thread({

            var socket: DatagramSocket? = null

            try {

                socket = DatagramSocket(5005)

                val buf = ByteArray(65507)

                val packet = DatagramPacket(buf, buf.size)

                while (listening) {

                    socket.receive(packet)

                    val s = String(packet.data, 0, packet.length, StandardCharsets.UTF_8).trim()

                    parseJson(s)

                }

            } catch (e: Exception) { e.printStackTrace() }

            finally { socket?.close() }

        })

        udpThread!!.start()

    }



    private fun parseJson(json: String) {

        try {

            val obj = JSONObject(json)



            // 1. Парсим Машины

            val rectsJson = obj.optJSONArray("rectangles")

            val carsList = mutableListOf<FloatArray>()

            if (rectsJson != null) {

                for (i in 0 until rectsJson.length()) {

                    val arr = rectsJson.optJSONArray(i)

                    if (arr != null && arr.length() >= 9) {

                        val d = FloatArray(9)

                        for (j in 0..8) d[j] = arr.optDouble(j).toFloat()

                        carsList.add(d)

                    }

                }

            }



            // 2. Парсим Парковочное место (ВОССТАНОВЛЕНО)

            val spotsJson = obj.optJSONArray("parking_spots")

            val spotsList = mutableListOf<FloatArray>()



            if (spotsJson != null) {

                for (i in 0 until spotsJson.length()) {

                    val arr = spotsJson.optJSONArray(i)

                    if (arr != null && arr.length() >= 8) {

                        val d = FloatArray(8)

                        for (j in 0..7) d[j] = arr.optDouble(j).toFloat()

                        spotsList.add(d)

                    }

                }

            }



                drawingView.updateData(carsList, spotsList)



        } catch (e: Exception) { /* Игнорируем ошибки парсинга */ }

    }



    class DrawingView(context: Context) : View(context) {



        // === ПЕРЕМЕННЫЕ УПРАВЛЕНИЯ ===

        private var pixelsPerMeter = 40f // Исходный масштаб

        private var panOffsetX = 0f    // Смещение по X (для сдвига)

        private var panOffsetY = 0f    // Смещение по Y (для сдвига)

        private var rotationAngle = 0f   // Угол поворота



        // === ДЕТЕКТОРЫ ЖЕСТОВ ===

        private val scaleDetector: ScaleGestureDetector

        private val gestureDetector: GestureDetector



        init {

            scaleDetector = ScaleGestureDetector(context, ScaleListener())

            gestureDetector = GestureDetector(context, GestureListener())

        }





        override fun onTouchEvent(event: MotionEvent): Boolean {

            scaleDetector.onTouchEvent(event)

            gestureDetector.onTouchEvent(event)



            // Ручная обработка вращения

            if (event.pointerCount == 2) {

                handleRotation(event)

            }

            return true

        }



        // =================================================================================

        // === ЛОГИКА ЖЕСТОВ ===

        // =================================================================================



        private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {

            override fun onScale(detector: ScaleGestureDetector): Boolean {

                pixelsPerMeter *= detector.scaleFactor

                pixelsPerMeter = pixelsPerMeter.coerceIn(5f, 300f) // Ограничение

                postInvalidate()

                return true

            }

        }



        private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {

                if (e2.pointerCount == 1) {

                    panOffsetX -= distanceX

                    panOffsetY -= distanceY

                    postInvalidate()

                }

                return true

            }

        }



        private var startAngle = 0f

        private var initialAngle = 0f



        private fun getAngle(event: MotionEvent): Float {

            val dx = event.getX(0) - event.getX(1)

            val dy = event.getY(0) - event.getY(1)

            // atan2 возвращает радианты, переводим в градусы

            return Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()

        }



        private fun handleRotation(event: MotionEvent) {

            when (event.actionMasked) {

                MotionEvent.ACTION_POINTER_DOWN -> {

                    initialAngle = rotationAngle

                    startAngle = getAngle(event)

                }

                MotionEvent.ACTION_MOVE -> {

                    val currentAngle = getAngle(event)

                    val rotationDelta = currentAngle - startAngle

                    rotationAngle = initialAngle + rotationDelta

                    postInvalidate()

                }

            }

        }



// =================================================================================

// === ЛОГИКА ОТРИСОВКИ ===

// =================================================================================





        // === КИСТИ ===

        private val paintCarRedStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.RED; strokeWidth = 5f; pathEffect = CornerPathEffect(8f) }

        private val paintCarRedFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#44FF0000") }

        private val paintCarYellowStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.YELLOW; strokeWidth = 5f; pathEffect = CornerPathEffect(8f) }

        private val paintCarYellowFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#44FFFF00") }

        private val paintSpotFree = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#5500FF00") }

        private val paintSpotOccupied = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.parseColor("#88FF0000") }

        private val paintSpotBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 3f; pathEffect = DashPathEffect(floatArrayOf(20f, 10f), 0f) }

        private val paintCam = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.CYAN }
        // Добавить кисти в поля класса:
        private val paintHudBg = Paint().apply { color = Color.parseColor("#CC000000"); style = Paint.Style.FILL }
        private val paintFree = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00CC44"); textSize = 40f; typeface = Typeface.DEFAULT_BOLD }
        private val paintOccupied = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF4444"); textSize = 40f; typeface = Typeface.DEFAULT_BOLD }
        private val paintGrid = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.DKGRAY; strokeWidth = 2f }
        private val paintGridText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL; color = Color.LTGRAY
            textSize = 32f; typeface = Typeface.DEFAULT_BOLD
        }
        private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 32f; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }

        private val paintLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {

            style = Paint.Style.STROKE

            color = Color.WHITE

            strokeWidth = 3f

        }

        private val pathCar = Path()

        private val pathSpot = Path()

        private val rectCarBounds = RectF()

        private val rectSpotBounds = RectF()



        private var allCars: List<FloatArray> = emptyList()

        private var parkingSpots: List<FloatArray> = emptyList()



        fun updateData(newCars: List<FloatArray>, newSpots: List<FloatArray>) {

            allCars = newCars

            parkingSpots = newSpots

            postInvalidate()

        }



        override fun onDraw(canvas: Canvas) {

            super.onDraw(canvas)



            val cx_base = width / 2f

            val cy_base = height - 50f



            canvas.save()

            canvas.translate(panOffsetX, panOffsetY)

            canvas.rotate(rotationAngle, cx_base, cy_base)



            // Сетка

            for (i in 1..20) {
                val r = i * 5f * pixelsPerMeter
                val oval = RectF(cx_base - r, cy_base - r, cx_base + r, cy_base + r)
                canvas.drawArc(oval, 180f, 180f, false, paintGrid)
                canvas.drawText("${i * 5}m", cx_base + r + 5, cy_base - 5, paintGridText)
            }

            canvas.drawCircle(cx_base, cy_base, 20f, paintCam)



            // === 1. РИСУЕМ ВСЕ ПАРКОВКИ ===

            // Создадим временный список границ, чтобы машины могли их "видеть"
            var occupiedCount = 0
            val allSpotBounds = mutableListOf<RectF>()



            for (spot in parkingSpots) {

                pathSpot.reset()

                pathSpot.moveTo(cx_base + spot[0] * pixelsPerMeter, cy_base - spot[1] * pixelsPerMeter)

                for (i in 2 until 8 step 2) {

                    pathSpot.lineTo(cx_base + spot[i] * pixelsPerMeter, cy_base - spot[i+1] * pixelsPerMeter)

                }

                pathSpot.close()



                val currentBounds = RectF()

                pathSpot.computeBounds(currentBounds, true)

                allSpotBounds.add(currentBounds)



                // Проверяем занятость конкретно этого места

                var thisSpotOccupied = false

                for (car in allCars) {

                    val cBounds = RectF()

                    val cPath = Path()

                    cPath.moveTo(cx_base + car[0] * pixelsPerMeter, cy_base - car[1] * pixelsPerMeter)

                    for (i in 2 until 8 step 2) cPath.lineTo(cx_base + car[i] * pixelsPerMeter, cy_base - car[i+1] * pixelsPerMeter)

                    cPath.close()

                    cPath.computeBounds(cBounds, true)



                    if (RectF.intersects(cBounds, currentBounds)) {

                        thisSpotOccupied = true

                        break

                    }

                }



                canvas.drawPath(pathSpot, if (thisSpotOccupied) paintSpotOccupied else paintSpotFree)

                canvas.drawPath(pathSpot, paintSpotBorder)

                canvas.drawText(if (thisSpotOccupied) "ЗАНЯТО" else "СВОБОДНО", currentBounds.centerX(), currentBounds.centerY(), paintText)
                if (thisSpotOccupied) occupiedCount++

            }



            // === 2. РИСУЕМ ВСЕ МАШИНЫ ===

            val CAR_W = 1.8f * pixelsPerMeter
            val CAR_L = 4.5f * pixelsPerMeter

            for (car in allCars) {
                val centerX = cx_base + ((car[0]+car[2]+car[4]+car[6]) / 4f) * pixelsPerMeter
                val centerY = cy_base - ((car[1]+car[3]+car[5]+car[7]) / 4f) * pixelsPerMeter

                pathCar.reset()
                pathCar.addRect(
                    centerX - CAR_L/2f, centerY - CAR_W/2f,
                    centerX + CAR_L/2f, centerY + CAR_W/2f,
                    Path.Direction.CW
                )
                pathCar.computeBounds(rectCarBounds, true)

                var carInSpot = false
                for (sBound in allSpotBounds) {
                    if (RectF.intersects(rectCarBounds, sBound)) { carInSpot = true; break }
                }

                canvas.drawPath(pathCar, if (carInSpot) paintCarRedFill else paintCarYellowFill)
                canvas.drawPath(pathCar, if (carInSpot) paintCarRedStroke else paintCarYellowStroke)
                // линии и текст дистанции УБРАНЫ
            }



            canvas.restore()
            val freeCount = parkingSpots.size - occupiedCount
            canvas.drawRoundRect(RectF(20f, 20f, 360f, 150f), 16f, 16f, paintHudBg)
            canvas.drawText("🟢 Свободно: $freeCount", 40f, 75f, paintFree)
            canvas.drawText("🔴 Занято: $occupiedCount", 40f, 130f, paintOccupied)
        }

    }

}